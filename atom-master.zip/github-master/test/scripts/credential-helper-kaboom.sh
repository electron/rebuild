#!/bin/sh

# Exit with some weird-ass failure code
exit 97
