#!/bin/sh

printf 'friend'
