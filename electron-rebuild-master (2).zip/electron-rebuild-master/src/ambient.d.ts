declare module 'detect-libc';
declare module 'node-abi';
